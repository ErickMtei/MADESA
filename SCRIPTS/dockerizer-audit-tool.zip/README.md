# Dockerizer Audit Tool

Usage:

```bash
python3 dockerizer-audit.py /opt/myapp
```

Also inspect the current Linux host:

```bash
python3 dockerizer-audit.py /opt/myapp --host
```

Generate into a chosen directory:

```bash
python3 dockerizer-audit.py /opt/myapp --output /opt/dockerized-myapp
```

The tool audits:
- OS/kernel/services/listening ports (with `--host`)
- application language/framework
- frontend/backend indicators
- package manifests and build/start commands
- .env filenames and variable names (not secret values)
- database/external-service indicators
- persistent-data candidates
- cron/process-manager indicators

It generates a first-pass:
- backend/Dockerfile
- frontend/Dockerfile
- nginx/nginx.conf
- docker-compose.yml
- .dockerignore
- .env.example
- AUDIT_REPORT.md
- HOST_AUDIT.txt when `--host` is used

Automatic detection cannot safely infer every production architecture. Review the generated files, especially runtime versions, WSGI/ASGI/Node entrypoints, ports, volumes, secrets, healthchecks, and external databases.
