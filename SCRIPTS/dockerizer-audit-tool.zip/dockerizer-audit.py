#!/usr/bin/env python3
"""
dockerizer-audit.py
Audit an existing application project and generate a first-pass Docker deployment.

Usage:
  python3 dockerizer-audit.py /path/to/project
  python3 dockerizer-audit.py /path/to/project --output ./dockerized
  python3 dockerizer-audit.py /path/to/project --host

The generated Dockerfiles/compose/nginx config are intentionally marked as
FIRST PASS. Always review secrets, ports, startup commands and persistent data
before production deployment.
"""

import argparse
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

IGNORE_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", "venv",
    "env", ".tox", ".mypy_cache", ".pytest_cache", "dist", "build",
    ".next", ".nuxt", "target"
}

def run(cmd):
    try:
        p = subprocess.run(cmd, shell=True, text=True, capture_output=True, timeout=15)
        return (p.stdout + p.stderr).strip()
    except Exception as e:
        return f"[command failed: {e}]"

def read(path, limit=200000):
    try:
        return path.read_text(errors="ignore")[:limit]
    except Exception:
        return ""

def exists(root, name):
    return (root / name).exists()

def find_files(root, names, max_results=50):
    found = []
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
        for f in files:
            if f in names:
                found.append(Path(base) / f)
                if len(found) >= max_results:
                    return found
    return found

def detect(root):
    d = {
        "languages": [],
        "frameworks": [],
        "frontend": False,
        "backend": False,
        "package_manager": None,
        "runtime": None,
        "start_command": None,
        "build_command": None,
        "ports": [],
        "databases": [],
        "external_services": [],
        "env_files": [],
        "persistent_paths": [],
        "cron_files": [],
        "confidence": [],
    }

    # Node / frontend / JS backend
    pkg = root / "package.json"
    if pkg.exists():
        try:
            p = json.loads(read(pkg))
            deps = {**p.get("dependencies", {}), **p.get("devDependencies", {})}
            d["languages"].append("JavaScript/TypeScript")
            if (root / "package-lock.json").exists():
                d["package_manager"] = "npm"
            elif (root / "yarn.lock").exists():
                d["package_manager"] = "yarn"
            elif (root / "pnpm-lock.yaml").exists():
                d["package_manager"] = "pnpm"
            else:
                d["package_manager"] = "npm"

            scripts = p.get("scripts", {})
            if "build" in scripts:
                d["build_command"] = f"{d['package_manager']} run build"

            if any(x in deps for x in ["react", "react-dom", "vite", "next", "vue", "nuxt", "angular", "@angular/core"]):
                d["frontend"] = True
                d["confidence"].append("package.json indicates a frontend ecosystem")
                if "vite" in deps:
                    d["frameworks"].append("Vite")
                if "react" in deps or "react-dom" in deps:
                    d["frameworks"].append("React")
                if "next" in deps:
                    d["frameworks"].append("Next.js")
                if "vue" in deps:
                    d["frameworks"].append("Vue")
                if "angular" in deps or "@angular/core" in deps:
                    d["frameworks"].append("Angular")

            if any(x in deps for x in ["express", "fastify", "nestjs", "@nestjs/core", "koa", "hapi"]):
                d["backend"] = True
                d["confidence"].append("package.json indicates a Node.js backend")
                d["runtime"] = "node"
                if scripts.get("start"):
                    d["start_command"] = scripts["start"]
                elif scripts.get("dev"):
                    d["start_command"] = scripts["dev"]

            if not d["frontend"] and not d["backend"]:
                if scripts.get("start"):
                    d["backend"] = True
                    d["runtime"] = "node"
                    d["start_command"] = scripts["start"]

        except Exception as e:
            d["confidence"].append(f"Could not parse package.json: {e}")

    # Python
    py_files = ["requirements.txt", "pyproject.toml", "Pipfile", "setup.py"]
    py = next((root / x for x in py_files if (root / x).exists()), None)
    if py:
        d["languages"].append("Python")
        d["backend"] = True
        d["runtime"] = "python"
        d["confidence"].append(f"found {py.name}")
        txt = read(py).lower()
        for name, label in [
            ("django", "Django"), ("flask", "Flask"), ("fastapi", "FastAPI"),
            ("gunicorn", "Gunicorn"), ("uvicorn", "Uvicorn"),
            ("celery", "Celery"), ("redis", "Redis"), ("mysql", "MySQL"),
            ("psycopg", "PostgreSQL")
        ]:
            if name in txt:
                d["frameworks"].append(label)

        if "manage.py" in [x.name for x in root.iterdir() if x.is_file()]:
            d["frameworks"].append("Django")
            d["start_command"] = "gunicorn"
        elif "flask" in txt or "fastapi" in txt:
            d["start_command"] = "REVIEW_REQUIRED"

    # PHP
    composer = root / "composer.json"
    if composer.exists():
        d["languages"].append("PHP")
        d["backend"] = True
        d["runtime"] = "php"
        d["confidence"].append("found composer.json")
        try:
            c = json.loads(read(composer))
            req = c.get("require", {})
            if "laravel/framework" in req:
                d["frameworks"].append("Laravel")
            if "symfony/framework-bundle" in req:
                d["frameworks"].append("Symfony")
            if "php" in req:
                d["confidence"].append(f"PHP constraint: {req['php']}")
        except Exception:
            pass

    # Java
    if (root / "pom.xml").exists() or (root / "build.gradle").exists() or (root / "build.gradle.kts").exists():
        d["languages"].append("Java")
        d["backend"] = True
        d["runtime"] = "java"
        d["confidence"].append("found Maven/Gradle build file")
        d["start_command"] = "REVIEW_REQUIRED"

    # Go
    if (root / "go.mod").exists():
        d["languages"].append("Go")
        d["backend"] = True
        d["runtime"] = "go"
        d["confidence"].append("found go.mod")
        d["start_command"] = "REVIEW_REQUIRED"

    # .NET
    cs = list(root.glob("*.csproj")) + list(root.glob("*.sln"))
    if cs:
        d["languages"].append(".NET")
        d["backend"] = True
        d["runtime"] = "dotnet"
        d["confidence"].append("found .csproj/.sln")
        d["start_command"] = "REVIEW_REQUIRED"

    # env files: report names/keys, never values
    for p in find_files(root, {".env", ".env.production", ".env.local", ".env.example"}):
        d["env_files"].append(str(p.relative_to(root)))
        if p.name != ".env.example":
            for line in read(p).splitlines():
                m = re.match(r"\s*([A-Za-z_][A-Za-z0-9_]*)\s*=", line)
                if m:
                    d.setdefault("env_keys", []).append(m.group(1))

    # Search configs for common ports/services
    text_files = find_files(
        root,
        {"docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml",
         "nginx.conf", "httpd.conf", "apache2.conf", ".env", ".env.example",
         "application.properties", "application.yml", "application.yaml",
         "settings.py", "config.py", "server.js", "app.js", "main.py"},
        100
    )
    blob = "\n".join(read(p) for p in text_files).lower()

    for port, label in [
        (80, "HTTP"), (443, "HTTPS"), (3000, "Node/frontend"),
        (3001, "Node/frontend"), (3002, "Node/frontend"),
        (8000, "Python/Django"), (8001, "Backend"),
        (8080, "Java/HTTP"), (5000, "Flask"), (3306, "MySQL"),
        (5432, "PostgreSQL"), (6379, "Redis"), (5672, "RabbitMQ"),
        (25, "SMTP"), (389, "LDAP"), (636, "LDAPS")
    ]:
        if re.search(rf"(?<!\d){port}(?!\d)", blob):
            d["ports"].append(f"{port} ({label})")

    for name, label in [
        ("mysql", "MySQL/MariaDB"), ("mariadb", "MySQL/MariaDB"),
        ("postgres", "PostgreSQL"), ("postgresql", "PostgreSQL"),
        ("redis", "Redis"), ("rabbitmq", "RabbitMQ"),
        ("ldap", "LDAP"), ("smtp", "SMTP")
    ]:
        if name in blob and label not in d["external_services"]:
            d["external_services"].append(label)

    # Persistent/application data candidates
    candidates = [
        "media", "uploads", "upload", "storage", "files", "public/uploads",
        "static", "staticfiles", "logs", "data", "var", "tmp"
    ]
    for c in candidates:
        p = root / c
        if p.exists() and p.is_dir():
            d["persistent_paths"].append(c)

    # Cron
    for p in find_files(root, {"crontab", "cron", "supervisord.conf", "celerybeat-schedule"}, 50):
        d["cron_files"].append(str(p.relative_to(root)))

    # Deduplicate
    for k in ["languages", "frameworks", "databases", "external_services", "ports", "persistent_paths", "env_keys"]:
        d[k] = list(dict.fromkeys(d.get(k, [])))

    return d

def host_audit():
    return {
        "os_release": run("cat /etc/os-release"),
        "kernel": run("uname -a"),
        "services": run("systemctl list-units --type=service --state=running --no-pager 2>/dev/null || true"),
        "processes": run("ps aux"),
        "ports": run("ss -tulpn 2>/dev/null || netstat -tulpn 2>/dev/null || true"),
        "cron": run("crontab -l 2>/dev/null || true"),
        "cron_dirs": run("ls -la /etc/cron* 2>/dev/null || true"),
    }

def dockerignore():
    return """# Generated by dockerizer-audit.py
.git
.gitignore
.env
.env.*
!.env.example
node_modules
__pycache__
*.pyc
.venv
venv
env
dist
build
.next
coverage
*.log
Dockerfile*
docker-compose*.yml
compose*.yml
"""

def nginx_conf():
    return """# Generated first-pass reverse proxy.
# Change backend:8000 to the actual backend service/port if required.
server {
    listen 80;
    server_name _;

    client_max_body_size 100M;

    location / {
        proxy_pass http://backend:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    location /health {
        access_log off;
        proxy_pass http://backend:8000/health;
    }
}
"""

def frontend_dockerfile():
    return """# FIRST PASS - review before production
FROM node:20-alpine AS build
WORKDIR /app

COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

FROM nginx:1.27-alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
"""

def python_dockerfile():
    return """# FIRST PASS - review Python/framework version before production
FROM python:3.12-slim

ENV PYTHONDONTWRITEBYTECODE=1 \
    PYTHONUNBUFFERED=1

WORKDIR /app

RUN apt-get update && apt-get install -y --no-install-recommends \
    build-essential default-libmysqlclient-dev pkg-config \
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8000

# REVIEW_REQUIRED: replace if the project uses Flask/FastAPI/another entrypoint.
CMD ["gunicorn", "--bind", "0.0.0.0:8000", "config.wsgi:application"]
"""

def node_backend_dockerfile():
    return """# FIRST PASS - review Node version and startup command
FROM node:20-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --omit=dev

COPY . .

ENV NODE_ENV=production
EXPOSE 3000

# REVIEW_REQUIRED: replace with the application's actual start command if needed.
CMD ["npm", "start"]
"""

def php_dockerfile(frameworks):
    if "Laravel" in frameworks:
        return """# FIRST PASS Laravel container
FROM php:8.3-apache

WORKDIR /var/www/html

RUN apt-get update && apt-get install -y --no-install-recommends \
    git unzip libzip-dev libpng-dev libonig-dev \
    && docker-php-ext-install pdo pdo_mysql mbstring zip \
    && rm -rf /var/lib/apt/lists/*

COPY --from=composer:2 /usr/bin/composer /usr/bin/composer
COPY composer.json composer.lock* ./
RUN composer install --no-dev --prefer-dist --no-interaction --optimize-autoloader

COPY . .

RUN a2enmod rewrite
EXPOSE 80
CMD ["apache2-foreground"]
"""
    return """# FIRST PASS PHP container
FROM php:8.3-apache
WORKDIR /var/www/html
COPY . .
EXPOSE 80
CMD ["apache2-foreground"]
"""

def compose(d):
    services = []
    volumes = []

    if d["frontend"]:
        services.append("""  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    restart: unless-stopped
    networks: [appnet]""")

    if d["backend"]:
        port = 8000 if d["runtime"] == "python" else 3000 if d["runtime"] == "node" else 8000
        services.append(f"""  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    restart: unless-stopped
    env_file:
      - ./backend/.env
    expose:
      - "{port}"
    networks: [appnet]""")

    # If neither was detected, make a clearly reviewable generic backend.
    if not d["backend"] and not d["frontend"]:
        services.append("""  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    restart: unless-stopped
    networks: [appnet]""")

    # nginx is only a generated proxy when frontend and backend are separate.
    if d["frontend"] and d["backend"]:
        services.append("""  nginx:
    image: nginx:1.27-alpine
    restart: unless-stopped
    ports:
      - "80:80"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/conf.d/default.conf:ro
    depends_on:
      - frontend
      - backend
    networks: [appnet]""")

    return """# FIRST PASS - review ports, healthchecks, secrets and dependencies
services:
%s

networks:
  appnet:
    driver: bridge
""" % "\n\n".join(services)

def write_report(out, d, host=None):
    lines = [
        "# Dockerization Audit Report",
        "",
        "## Detected application",
        f"- Languages: {', '.join(d['languages']) or 'UNKNOWN'}",
        f"- Frameworks: {', '.join(d['frameworks']) or 'UNKNOWN'}",
        f"- Frontend detected: {d['frontend']}",
        f"- Backend detected: {d['backend']}",
        f"- Runtime: {d['runtime'] or 'UNKNOWN'}",
        f"- Package manager: {d['package_manager'] or 'N/A'}",
        f"- Build command: {d['build_command'] or 'UNKNOWN'}",
        f"- Start command: {d['start_command'] or 'UNKNOWN'}",
        "",
        "## Ports/services discovered",
        *(f"- {x}" for x in d["ports"]),
        *(f"- External service: {x}" for x in d["external_services"]),
        "",
        "## Environment",
        f"- Environment files: {', '.join(d['env_files']) or 'none found'}",
        f"- Environment keys: {', '.join(d.get('env_keys', [])) or 'none detected'}",
        "",
        "## Persistent data candidates",
        *(f"- {x}" for x in d["persistent_paths"]),
        "",
        "## Scheduled jobs / process managers",
        *(f"- {x}" for x in d["cron_files"]),
        "",
        "## Confidence notes",
        *(f"- {x}" for x in d["confidence"]),
        "",
        "## Review before production",
        "- Confirm exact runtime versions from the application lockfiles/manifests.",
        "- Confirm the real backend startup command and WSGI/ASGI/module path.",
        "- Never commit .env or real credentials.",
        "- Confirm which databases/services are external versus Docker-managed.",
        "- Add healthchecks and dependency readiness before production.",
        "- Decide which directories require named volumes or bind mounts.",
        "- Add TLS at the edge/reverse proxy and configure trusted proxy headers.",
        "- Run vulnerability/image scans before release.",
    ]
    (out / "AUDIT_REPORT.md").write_text("\n".join(lines))

    if host is not None:
        h = out / "HOST_AUDIT.txt"
        h.write_text(
            "=== OS ===\n" + host["os_release"] +
            "\n\n=== KERNEL ===\n" + host["kernel"] +
            "\n\n=== RUNNING SERVICES ===\n" + host["services"] +
            "\n\n=== LISTENING PORTS ===\n" + host["ports"] +
            "\n\n=== CRON ===\n" + host["cron"] +
            "\n\n=== CRON DIRECTORIES ===\n" + host["cron_dirs"]
        )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("project", help="Existing application directory")
    ap.add_argument("--output", default="./dockerized-output")
    ap.add_argument("--host", action="store_true", help="Also audit the current Linux host")
    args = ap.parse_args()

    root = Path(args.project).resolve()
    out = Path(args.output).resolve()

    if not root.is_dir():
        raise SystemExit(f"Project directory not found: {root}")

    d = detect(root)
    out.mkdir(parents=True, exist_ok=True)

    # Copy source into backend/frontend folders only when appropriate.
    # We do not copy .git, secrets, or node_modules.
    if d["frontend"] and d["backend"]:
        front = out / "frontend"
        back = out / "backend"
        front.mkdir(exist_ok=True)
        back.mkdir(exist_ok=True)

        # Conservative heuristic: frontend source files/packages go to frontend,
        # backend manifests/server files go to backend. For mixed repositories,
        # a human review is required.
        frontend_names = {"package.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
                          "vite.config.js", "vite.config.ts", "tsconfig.json", "index.html"}
        for item in root.iterdir():
            if item.name in frontend_names or item.name in {"src", "public"}:
                dest = front / item.name
            elif item.name in IGNORE_DIRS or item.name.startswith(".env"):
                continue
            else:
                dest = back / item.name
            if item.is_dir():
                shutil.copytree(item, dest, dirs_exist_ok=True,
                                ignore=shutil.ignore_patterns(*IGNORE_DIRS, ".env", ".env.*"))
            else:
                shutil.copy2(item, dest)

        # Copy package metadata if a frontend was detected.
        (front / ".dockerignore").write_text(dockerignore())
        (back / ".dockerignore").write_text(dockerignore())

        (front / "Dockerfile").write_text(frontend_dockerfile())

        if d["runtime"] == "python":
            (back / "Dockerfile").write_text(python_dockerfile())
        elif d["runtime"] == "node":
            (back / "Dockerfile").write_text(node_backend_dockerfile())
        elif d["runtime"] == "php":
            (back / "Dockerfile").write_text(php_dockerfile(d["frameworks"]))
        else:
            (back / "Dockerfile").write_text(
                "# REVIEW_REQUIRED: backend runtime was detected but no safe Dockerfile template was selected.\n"
            )

        (out / "nginx").mkdir(exist_ok=True)
        (out / "nginx" / "nginx.conf").write_text(nginx_conf())

    elif d["backend"]:
        back = out / "backend"
        shutil.copytree(root, back, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns(*IGNORE_DIRS, ".env", ".env.*"))
        (back / ".dockerignore").write_text(dockerignore())

        if d["runtime"] == "python":
            (back / "Dockerfile").write_text(python_dockerfile())
        elif d["runtime"] == "node":
            (back / "Dockerfile").write_text(node_backend_dockerfile())
        elif d["runtime"] == "php":
            (back / "Dockerfile").write_text(php_dockerfile(d["frameworks"]))
        else:
            (back / "Dockerfile").write_text("# REVIEW_REQUIRED: create the correct runtime Dockerfile.\n")

    elif d["frontend"]:
        front = out / "frontend"
        shutil.copytree(root, front, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns(*IGNORE_DIRS, ".env", ".env.*"))
        (front / ".dockerignore").write_text(dockerignore())
        (front / "Dockerfile").write_text(frontend_dockerfile())
    else:
        back = out / "backend"
        shutil.copytree(root, back, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns(*IGNORE_DIRS, ".env", ".env.*"))
        (back / "Dockerfile").write_text(
            "# REVIEW_REQUIRED: application type could not be detected automatically.\n"
        )

    (out / "docker-compose.yml").write_text(compose(d))

    # Always make an example env placeholder rather than copying secrets.
    env_example = out / ".env.example"
    if not env_example.exists():
        keys = d.get("env_keys", [])
        env_example.write_text(
            "# Fill these values manually. DO NOT put production secrets in Git.\n" +
            "\n".join(f"{k}=" for k in keys)
        )

    host = host_audit() if args.host else None
    write_report(out, d, host)

    print(f"Audit complete: {out}")
    print("Generated:")
    for p in sorted(out.rglob("*")):
        if p.is_file():
            print("  ", p.relative_to(out))
    print("\nIMPORTANT: Generated Docker files are a first pass. Review AUDIT_REPORT.md before production.")

if __name__ == "__main__":
    main()
